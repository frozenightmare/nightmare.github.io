---
layout: default
title: Credits
nav_exclude: true
search_exclude: true
---

- Template: [Just the Docs](https://github.com/just-the-docs/just-the-docs)
- Hầu hết hướng dẫn ma trận từ [I Like Tortoises](https://youtube.com/@G00d_Morning), bạn của mình và chuyên nghiên cứu lỗi máy tính Casio
- Một số hướng dẫn ma trận từ [forum fx-es(ms)](https://tieba.baidu.com/f?kw=fx-es%28ms%29&ie=utf-8) trên Baidu Tieba (lưu ý: tiếng Trung Quốc)
- Các phông chữ được sử dụng:
  - [ClassWiz X/CW Display](https://github.com/Wenti-D/ClasswizDisplayFont)
  - [Phông bàn phím](https://edu.casio.com/forteachers/er/fontsets)

## Plugin
- [jekyll-last-modified-at](https://github.com/gjtorikian/jekyll-last-modified-at)
- Plugin ngày sửa đổi của mình (tạo dùng ChatGPT)
- [MathJax](https://www.mathjax.org/)

(c) [gamingwithevets.github.io](/)