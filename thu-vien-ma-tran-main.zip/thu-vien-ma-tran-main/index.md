---
title: Thông báo quan trọng
layout: home
nav_exclude: true
search_exclude: true
---

Lưu ý: Thư Viện Ma Trận đang thử nghiệm với nhiều phông cùng một lúc.

Thư Viện Ma Trận đã được tạo vào ngày **31/01/2023** và đã đóng cửa vào ngày **05/06/2023**... cho đến ngày hôm nay (**22/03/2024**), tôi đã quyết định mở lại Thư Viện Ma Trận để thông báo về **Phan Tất Dũng**.

Phan Tất Dũng (gọi tắt là PTD) là một người ăn cắp và sử dụng trend hack máy tính Casio để kiếm tiền.

Đây là những gì PTD đang bán hiện tại (**VUI LÒNG ĐỪNG MUA**):
- File gõ chữ tiếng Anh và tiếng Việt (kể cả phông chữ lớn và nhỏ) + "1 số lỗi thú vị" + vẽ trên fx-580VN X (có trong máy chủ Casio Calculator Spelling) + gõ chữ trên fx-880BTG
- "VnX+" Bot trợ giúp gõ chữ
- Các thứ khác (chợ đen, có cả bảo hành): Discord Nitro, Discord server 14 boosts, YouTube Premium, Spotify Premium, Netflix Premium, Canva Pro, key Minecraft và Minecraft Dungeons, Robux, ChatGPT, follower, Locket Gold

Đây là bằng chứng lừa đảo:
- PTD đã lấy thông tin từ các nguồn như [các video của MeowIce](https://youtube.com/@meowice64), [Baidu Tieba](https://tieba.baidu.com/f?kw=fx-es(ms)) và **chính website này** để tạo file (mà không hề ghi nguồn, tự cho là của mình hết)
- [Giả lập của PTD](https://e.ptdung.site) ăn cắp của [e.20142022.xyz](https://e.20142022.xyz)
- [Trang web "Thư Viện Ma Trận" của PTD](https://tvmt.ptdung.site) **hoàn toàn được sao chép từ trang web này**, chỉ bỏ trang như credits và thông tin bản quyền (về credit thì PTD tự nhận là mình tạo hết)
- PTD còn dùng phông ClassWiz X Display Unofficial (mod ClassWiz X Display 1.003 của tôi tạo), tôi không còn cho ai dùng phông này nữa.
- Giả lập "xịn" mới nhất của PTD cũng được ăn cắp từ [GitHub](https://github.com/qiufuyu123/CasioEmuNeo)

**Xin tránh xa PTD dưới mọi hình thức!**

\- Steveyboi
