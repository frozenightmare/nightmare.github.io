---
title: Lỗi kì lạ
layout: default
parent: Lỗi máy tính
grand_parent: Dòng máy ClassWiz (thế hệ 2)
---

# Lỗi kì lạ
Lỗi kì lạ là những thông báo lỗi được hiện ra không đúng chỗ.

*Lưu ý: Những tên lựa chọn và lỗi kì lạ sẽ là của giao diện Tiếng Anh. Để chuột lên chúng để xem bản tiếng Việt.*

## Cách bấm
[N/A]