---
title: Kí tự an
layout: default
parent: Lỗi máy tính
grand_parent: Dòng máy ClassWiz
---

# Kí tự an
Kí tự `an` là một trong các [*Weird Symbol*](/thu-vien-ma-tran/docs/classwiz/loi-may-tinh/ws.html) có thể nhập qua [CC](/thu-vien-ma-tran/docs/classwiz/loi-may-tinh/cc.html).

## Cách bấm
[Sử dụng CC để ra kí tự `an`.](/thu-vien-ma-tran/docs/classwiz/loi-may-tinh/ws.html#cách-bấm)