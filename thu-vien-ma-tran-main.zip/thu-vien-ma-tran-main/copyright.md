---
layout: default
title: Copyright informtion
nav_exclude: true
search_exclude: true
---

# Copyright information
*(Thông tin bản quyền - Tiếng Anh)*

About the website content: Please adhere to the [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0) license.

Please **give credit** if you want to use any information on TVMT/Matrix Library.

NOTE: If you are still using the **ClassWiz X Display Unofficial** font from previous versions of the website, please **switch to the [official version](https://github.com/Wenti-D/ClasswizDisplayFont)**.
